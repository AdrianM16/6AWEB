import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

// Angular Material Imports
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSliderModule } from '@angular/material/slider';
import { MatButtonModule } from '@angular/material/button';
// Extra Material Components (+3 required)
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatStepperModule } from '@angular/material/stepper';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSliderModule,
    MatButtonModule,
    MatSelectModule,
    MatCheckboxModule,
    MatIconModule,
    MatChipsModule,
    MatStepperModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatSnackBarModule
  ],
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class RegisterComponent {
  constructor(private snackBar: MatSnackBar) {}

  submitted: boolean = false;
  hidePassword: boolean = true;

  minSkillLevel: number = 1;
  maxSkillLevel: number = 10;

  countries: string[] = [
    'Philippines', 'United States', 'Japan', 'South Korea',
    'Australia', 'Canada', 'United Kingdom', 'Germany'
  ];

  cities: string[] = [
    'Angeles City',
    'City of San Fernando',
    'Mabalacat',
    'Magalang',
    'Mexico',
    'Guagua',
    'Apalit',
    'Arayat'
  ];

  interests: string[] = ['Web Dev', 'UI/UX', 'Mobile Apps', 'Backend', 'Cloud'];
  selectedInterests: string[] = [];

  accountGroup = new FormGroup({
    userName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(8)])
  });

  profileGroup = new FormGroup({
    gender: new FormControl('', [Validators.required]),
    birthDate: new FormControl<Date | null>(null, [Validators.required]),
    country: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    address: new FormControl('')
  });

  prefsGroup = new FormGroup({
    angularSkillLevel: new FormControl(5),
    newsletter: new FormControl(true),
    agreeToTerms: new FormControl(false, [Validators.requiredTrue])
  });

  formdata = new FormGroup({
    account: this.accountGroup,
    profile: this.profileGroup,
    prefs: this.prefsGroup
  });

  toggleInterest(interest: string): void {
    const idx = this.selectedInterests.indexOf(interest);
    if (idx >= 0) {
      this.selectedInterests.splice(idx, 1);
    } else {
      this.selectedInterests.push(interest);
    }
  }

  isSelected(interest: string): boolean {
    return this.selectedInterests.includes(interest);
  }

  get cityOptions(): string[] {
    const raw = (this.profileGroup.get('city')?.value ?? '').toString().toLowerCase();
    if (!raw) return this.cities;
    return this.cities.filter(c => c.toLowerCase().includes(raw));
  }

  onClickSubmit(): void {
    this.submitted = true;

    if (this.formdata.valid) {
      this.snackBar.open('Saved! Your signup info is ready.', 'OK', { duration: 2500 });
      console.log('Form Submitted Successfully!', this.formdata.value);
    } else {
      this.snackBar.open('Please complete the required fields first.', 'OK', { duration: 2500 });
      console.log('Form is not valid!');
      this.formdata.markAllAsTouched();
    }
  }

  resetAll(): void {
    this.formdata.reset();
    this.prefsGroup.patchValue({ angularSkillLevel: 5, newsletter: true, agreeToTerms: false });
    this.submitted = false;
    this.selectedInterests = [];
  }
}