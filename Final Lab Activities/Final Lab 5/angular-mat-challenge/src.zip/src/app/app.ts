import { Component } from '@angular/core';
import { SignupComponent } from './signup/signup';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [SignupComponent, MatToolbarModule, MatIconModule],
  template: `
    <mat-toolbar color="primary" class="topbar">
      <mat-icon aria-hidden="true">school</mat-icon>
      <span class="title">Angular Material Hands-on Challenge</span>
      <span class="spacer"></span>
      <span class="name">Adrian Anunciacion</span>
    </mat-toolbar>
    <app-signup></app-signup>
  `,
  styles: [`
    .topbar{ position: sticky; top: 0; z-index: 10; }
    .title{ margin-left: 8px; font-weight: 600; }
    .spacer{ flex: 1; }
    .name{ font-size: 13px; opacity: 0.9; }
  `]
})
export class App {
  title = 'angular-mat-challenge';
}