import { Component, signal } from '@angular/core';
import { FormControl, FormGroup, Validators, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { CommonModule } from '@angular/common';

// Angular Material
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSliderModule } from '@angular/material/slider';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatBadgeModule } from '@angular/material/badge';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatAutocompleteModule } from '@angular/material/autocomplete';

// ── Custom Validators ──────────────────────────────────────────
function alphanumericPasswordValidator(control: AbstractControl): ValidationErrors | null {
  const value: string = control.value || '';
  if (!value) return null;
  const startsWithLetter = /^[a-zA-Z]/.test(value);
  const alphanumericOnly = /^[a-zA-Z0-9]+$/.test(value);
  if (!startsWithLetter) return { startsWithLetter: true };
  if (!alphanumericOnly) return { alphanumericOnly: true };
  return null;
}

function birthYearValidator(control: AbstractControl): ValidationErrors | null {
  if (!control.value) return null;
  const year = new Date(control.value).getFullYear();
  if (year > 2006) return { tooYoung: true };
  return null;
}

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSliderModule,
    MatButtonModule,
    MatSelectModule,
    MatCheckboxModule,
    MatIconModule,
    MatTooltipModule,
    MatDividerModule,
    MatChipsModule,
    MatSlideToggleModule,  // Extra #1
    MatBadgeModule,        // Extra #2
    MatProgressBarModule,  // Extra #3
    MatStepperModule,      // Extra #4 (bonus)
    MatSnackBarModule,     // Extra #5 (bonus)
    MatAutocompleteModule, // Extra #6 (bonus)
  ],
  templateUrl: './signup.html',
  styleUrl: './signup.css'
})
export class SignupComponent {

  constructor(private snack: MatSnackBar) {}

  // ── Theme ──────────────────────────────────────────────────
  darkMode = signal(true);
  toggleTheme() { this.darkMode.update(v => !v); }

  // ── UI State ───────────────────────────────────────────────
  hidePassword = true;
  submitted = false;

  // ── Result Data ────────────────────────────────────────────
  fullName = '';
  studentId = '';
  email = '';
  gender = '';
  birthDate!: Date;
  eventType = '';
  ticketType = '';
  participationLevel = 5;
  notes = '';
  city = '';

  // ── Options ────────────────────────────────────────────────
  eventTypes = ['Tech Talk', 'Workshop', 'Hackathon', 'Seminar', 'Campus Fair'];
  ticketTypes = ['Free Pass', 'Student Pass', 'Regular Pass'];
  tracks: string[] = ['Web Dev', 'UI/UX', 'Cloud', 'Data', 'Mobile'];
  selectedTracks: string[] = [];

  cities = [
    'Angeles City',
    'City of San Fernando',
    'Mabalacat',
    'Apalit',
    'Mexico',
    'Guagua',
    'Bacolor',
  ];

  minSkill = 1;
  maxSkill = 10;
  maxDate = new Date(2006, 11, 31); // born 2006 or earlier

  // ── Form ───────────────────────────────────────────────────
  form = new FormGroup({
    fullName:   new FormControl('', [Validators.required, Validators.minLength(3)]),
    studentId:  new FormControl('', [Validators.required, Validators.minLength(6)]),
    email:      new FormControl('', [Validators.required, Validators.email]),
    password:   new FormControl('', [Validators.required, Validators.minLength(8), alphanumericPasswordValidator]),
    gender:     new FormControl('', [Validators.required]),
    birthDate:  new FormControl<Date | null>(null, [Validators.required, birthYearValidator]),
    city:       new FormControl('', [Validators.required]),
    eventType:  new FormControl('', [Validators.required]),
    ticketType: new FormControl('', [Validators.required]),
    participationLevel: new FormControl(5),
    notes:      new FormControl(''),
    newsletter: new FormControl(false),
    agreeToTerms: new FormControl(false, [Validators.requiredTrue]),
  });

  // ── Password Strength ──────────────────────────────────────
  get passwordStrength(): number {
    const v = this.form.get('password')?.value || '';
    let score = 0;
    if (v.length >= 8)  score += 25;
    if (v.length >= 12) score += 25;
    if (/[A-Z]/.test(v)) score += 25;
    if (/[0-9]/.test(v)) score += 25;
    return score;
  }

  get passwordStrengthLabel(): string {
    const s = this.passwordStrength;
    if (s <= 25)  return 'Weak';
    if (s <= 50)  return 'Fair';
    if (s <= 75)  return 'Good';
    return 'Strong';
  }

  get passwordStrengthColor(): string {
    const s = this.passwordStrength;
    if (s <= 25)  return 'warn';
    if (s <= 50)  return 'accent';
    return 'primary';
  }

  // ── Tracks ────────────────────────────────────────────────
  toggleTrack(track: string) {
    const i = this.selectedTracks.indexOf(track);
    i >= 0 ? this.selectedTracks.splice(i, 1) : this.selectedTracks.push(track);
  }

  isTrackSelected(track: string) { return this.selectedTracks.includes(track); }

  // ── Submit ─────────────────────────────────────────────────
  onSubmit(data: any) {
    this.submitted = true;
    if (this.form.valid) {
      this.fullName   = data.fullName   ?? '';
      this.studentId  = data.studentId  ?? '';
      this.email      = data.email      ?? '';
      this.gender     = data.gender     ?? '';
      this.birthDate  = data.birthDate;
      this.city       = data.city       ?? '';
      this.eventType  = data.eventType  ?? '';
      this.ticketType = data.ticketType ?? '';
      this.participationLevel = data.participationLevel ?? 5;
      this.notes      = data.notes      ?? '';

      this.snack.open('Submitted successfully!', 'OK', { duration: 2500 });
    } else {
      this.snack.open('Please fix the errors before submitting.', 'OK', { duration: 3000 });
    }
  }

  onReset() {
    this.form.reset({ participationLevel: 5 });
    this.submitted = false;
    this.selectedTracks = [];
  }
}